"use client";

import ProteinChat from "@/components/ProteinChat";

export default function ProteinChatClient() {
  return <ProteinChat />;
}
